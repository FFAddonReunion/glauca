pref("extensions.glauca@daiheitan.com.show_mine", true);
pref("extensions.glauca@daiheitan.com.display_forwardtype", 0);
pref("extensions.glauca@daiheitan.com.display_autofit", false);
pref("extensions.glauca@daiheitan.com.display_showRt", true);
pref("extensions.glauca@daiheitan.com.display_showPicIcon", true);
pref("extensions.glauca@daiheitan.com.display_showVideoIcon", true);
pref("extensions.glauca@daiheitan.com.display_nameLength", 6);
pref("extensions.glauca@daiheitan.com.display_weiboLength", 16);
